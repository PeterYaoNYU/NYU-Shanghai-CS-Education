def purchase_combination(Y_cost, X, Z):
    """
    Y_cost: a list of costs of each appliance brand. e.g. Y_cost = [[1, 5], [2, 4, 3, 6]]. All costs are > 0
    The number of brands for appliance type 0 is 2, which corresponds to cost [1, 5] from Y_cost[0].
    The number of brands for appliance type 1 is 4, which corresponds to cost [2, 4, 3, 6] from Y_cost[1].
    X: Total money you have
    Z: Minimum spending, and Z < X
    Return: A list of tuples containing the index of each appliance selected.
    """
    # TODO
    return []


def main():
    Y_cost = [[1,5], [2,4,3,6]]
    X = 12
    Z = 9
    print(purchase_combination(Y_cost, X, Z)) # Expect: results = [(1,1), (1,3)]


if __name__ == "__main__":
    main()