def pascal(k):
    """
    :param k: Int -- Level k of pascal triangle

    :return: List[Int] -- a list of pascal values at level k
    """
    pass


def main():
    print(pascal(4))    # [1, 3, 3, 1]
    print(pascal(0))    # [1]
    print(pascal(5))    # [1, 5, 10, 10, 5, 1]


if __name__ == '__main__':
    main()







